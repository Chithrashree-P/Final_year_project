<?php
// Database connection
$host = "localhost";
$dbname = "milk";
$username = "root";
$password = "";

try {
    // Create a new PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $user = $_POST['username'];
        $pass = $_POST['password'];

        // Check if the username already exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->bindParam(':username', $user);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            // If the username exists, redirect with an error
            header("Location: signup.html?error=Username already exists.");
            exit();
        } else {
            // Insert new user into the database
            $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (:username, :password)");
            $stmt->bindParam(':username', $user);
            $stmt->bindParam(':password', $pass);
            $stmt->execute();

            // Redirect to login page after successful registration
            header("Location: login.html?message=Registration successful. Please log in.");
            exit();
        }
    }
} catch (PDOException $e) {
    // Handle errors
    echo "Error: " . $e->getMessage();
    exit();
}
?>
