<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Milk Quality Analyzer Report</title>
  <link rel="stylesheet" href="styles.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <style>
    /* Responsive Design */
    @media (max-width: 768px) {
      .navbar {
        flex-direction: column;
        align-items: flex-start;
      }

      .content ul {
        padding-left: 20px;
        background-color: beige;
      }
    }

    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: #333;
      padding: 10px 20px;
    }

    .navbar a {
      color: white;
      text-decoration: none;
      margin: 0 15px;
    }

    .navbar a:hover {
      text-decoration: underline;
    }

    .container {
      padding: 20px;
    }

    header {
      text-align: center;
    }

    .sensor-data,
    .quality {
      margin-top: 20px;
    }

    .sensor {
      margin-bottom: 10px;
    }

    .sensor label {
      font-weight: bold;
    }

    .download-button {
      margin-top: 20px;
      padding: 10px 20px;
      background-color: #333;
      color: white;
      border: none;
      cursor: pointer;
      font-size: 16px;
      border-radius: 5px;
    }

    .download-button:hover {
      background-color: #555;
    }

    .signature-section {
      margin-top: 30px;
      text-align: center;
    }
  </style>
</head>

<body>

  <!-- Navbar with Links -->
  <nav class="navbar">
    <div class="logo">Milk Quality Analyzer</div>
    <div>
      <a href="index.html">Home</a>
      <a href="about.html">About</a>
      <a href="farmer.html">Farmer</a>
      <a href="milk.php">Real-time</a>
    </div>
  </nav>

  <div class="container" id="content">
    <header>
      <h1>Milk Quality Analyzer Report</h1>
      <p>Generated on: <span id="date"><?php echo date("Y-m-d H:i:s"); ?></span></p>
    </header>

    <section class="sensor-data">
      <h2>Sensor Data Summary</h2>
      <div class="sensor">
        <label>Temperature:</label>
        <span id="temperature">Loading...</span> °C
      </div>
      <div class="sensor">
        <label>pH Level:</label>
        <span id="ph">Loading...</span>
      </div>
      <div class="sensor">
        <label>Milk Quality:</label>
        <span id="color">Loading...</span>
      </div>
      <div class="sensor">
        <label>Gas Level:</label>
        <span id="gas">Loading...</span> ppm
      </div>
      <div class="sensor">
        <label>Ultrasonic Fat Level:</label>
        <span id="ultrasonic">Loading...</span> mm
      </div>
    </section>

    <section class="quality">
      <h2>Milk Quality Assessment</h2>
      <p>Milk Quality: <span id="milk-quality">Loading...</span></p>
    </section>

    <section class="signature-section">
      <h3>Digital Signature</h3>
      <p>___________________________</p>
      <p>Authorized Signature</p>
    </section>
  </div>

  <button class="download-button" onclick="downloadPDF()">Download as PDF</button>

  <script>
    // Function to fetch and update the data from the server
    function updateData() {
      $.ajax({
        url: 'fetch_data.php',  // The PHP script to fetch data
        method: 'GET',
        dataType: 'json',
        cache: false,  // Disable caching
        success: function (data) {
          if (data.error) {
            alert(data.error);
            return;
          }

          // Update the content with new data
          $('#temperature').text(data.records[0].temperature);
          $('#ph').text(data.records[0].ph_level);
          $('#color').text(data.records[0].color_temp);
          $('#gas').text(data.records[0].gas_level);
          $('#ultrasonic').text(data.records[0].ultrasonic_level);
          $('#milk-quality').text(data.records[0].milk_quality);

          // Update the current date
          $('#date').text(new Date().toLocaleString());
        }
      });
    }

    // Call updateData initially
    updateData();

    // Set interval to refresh the data every 10 seconds (10000 milliseconds)
    setInterval(updateData, 10000);

    // Function to generate and download the PDF
    function downloadPDF() {
      const content = document.getElementById('content');

      // PDF options
      const options = {
        margin: 0.5,
        filename: 'Milk_Quality_Report.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2 },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };

      // Generate the PDF
      html2pdf().set(options).from(content).save();
    }
  </script>
</body>

</html>
