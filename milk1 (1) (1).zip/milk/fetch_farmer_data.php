<?php
// Database connection details
$host = 'localhost'; // Your database host
$dbname = 'milk_quality'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

// Create a new PDO instance
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // If connection fails, log the error and return a general message
    error_log("Database Connection Error: " . $e->getMessage());
    echo json_encode(["error" => "Database connection failed."]);
    exit;
}

// Check if the farmer_id is passed as a GET parameter
if (isset($_GET['farmer_id'])) {
    $farmer_id = $_GET['farmer_id'];

    // Validate the Farmer ID (assuming it's alphanumeric)
    if (!preg_match('/^[a-zA-Z0-9]+$/', $farmer_id)) {
        echo json_encode(['error' => 'Invalid Farmer ID format']);
        exit;
    }

    // SQL query to fetch farmer data based on Farmer ID
    $sql = "SELECT * FROM milk_data WHERE farmer_id = :farmer_id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':farmer_id', $farmer_id, PDO::PARAM_STR);

    try {
        // Execute the query
        $stmt->execute();
        
        // Fetch all records for the given farmer_id
        $records = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // If records are found, return them as JSON
        if ($records) {
            echo json_encode(['records' => $records]);
        } else {
            // If no records found, return a message
            echo json_encode(['error' => 'No records found for the given Farmer ID']);
        }
    } catch (PDOException $e) {
        // If an error occurs, log the error and return a general error message
        error_log("Query Error: " . $e->getMessage());
        echo json_encode(['error' => 'Error fetching data']);
    }
} else {
    // If no farmer_id is passed, return an error message
    echo json_encode(['error' => 'Farmer ID is required']);
}
?>
