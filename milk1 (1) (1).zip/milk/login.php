<?php
// Database connection
$host = "localhost";
$dbname = "milk";
$username = "root";
$password = "";

session_start();

try {
    // Create a new PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $user = $_POST['username'];
        $pass = $_POST['password'];

        // Query to check if the username and password match
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username AND password = :password");
        $stmt->bindParam(':username', $user);
        $stmt->bindParam(':password', $pass);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $_SESSION['username'] = $user;  // Store the username in session
            header("Location: home.html");  // Redirect to the main page after successful login
            exit();
        } else {
            // Redirect with error message if invalid login
            header("Location: login.html?error=Invalid username or password.");
            exit();
        }
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
    exit();
}
?>
