<?php

// Database connection details
$hostname = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "milk"; // Database name

// Create connection
$conn = mysqli_connect($hostname, $username, $password, $database);

// Check connection
if (!$conn) { 
    die("Connection failed: " . mysqli_connect_error()); 
} 

echo "Database connection is OK<br>"; 

// Check if required POST data is set
if (
    isset($_POST["temp"]) &&
    isset($_POST["ph"]) &&
    isset($_POST["color"]) &&
    isset($_POST["gas"]) &&
    isset($_POST["fat"]) &&
    isset($_POST["status"])
) {
    // Retrieve POST data
    $batch_id = isset($_POST["batch_id"]) ? $_POST["batch_id"] : "UNKNOWN"; // Optional batch ID
    $temp = $_POST["temp"];
    $ph = $_POST["ph"];
    $color = $_POST["color"];
    $gas = $_POST["gas"];
    $fat = $_POST["fat"];
    $status = $_POST["status"];

    // Validate numeric values
    $temp = is_numeric($temp) ? $temp : 0;
    $ph = is_numeric($ph) ? $ph : 0;
    $gas = is_numeric($gas) ? $gas : 0;
    $fat = is_numeric($fat) ? $fat : 0;

    // Prepare SQL query
    $sql = "INSERT INTO milk_quality_analysis (
        temperature_value, ph_sensor_value, color_sensor_value, gas_sensor_value, ultrasonic_sensor_value, quality_status
    ) VALUES (
         $temp, $ph, '$color', $gas, $fat, '$status'
    )";

    // Execute query
    if (mysqli_query($conn, $sql)) { 
        echo "New record created successfully"; 
    } else { 
        echo "Error: " . $sql . "<br>" . mysqli_error($conn); 
    }
} else {
    echo "Error: Missing required POST parameters. Received: ";
    print_r($_POST); // Debugging aid to print received parameters
}

// Close connection
mysqli_close($conn);
?>