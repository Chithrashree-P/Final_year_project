<?php
session_start();

if (isset($_SESSION['username'])) {
    header("Location: milk.php");  // Redirect to home page if already logged in
    exit();
}
?>
