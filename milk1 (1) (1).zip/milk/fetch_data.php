<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database connection parameters
$servername = "localhost"; // Replace with your server details
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "milk"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['error' => 'Connection failed: ' . $conn->connect_error]));
}

// SQL query to fetch all data from the milk_quality_analysis table
$sql = "SELECT id, temperature_value, ph_sensor_value, color_sensor_value, gas_sensor_value, ultrasonic_sensor_value, quality_status, created_at 
        FROM milk_quality_analysis";

// Execute the query
$result = $conn->query($sql);

// Check if records are found
if ($result->num_rows > 0) {
    $records = [];
    
    // Fetch all records
    while ($row = $result->fetch_assoc()) {
        $records[] = [
            'timestamp' => $row['created_at'],
            'temperature' => $row['temperature_value'],
            'ph_level' => $row['ph_sensor_value'],
            'color_temp' => $row['color_sensor_value'],
            'gas_level' => $row['gas_sensor_value'],
            'ultrasonic_level' => $row['ultrasonic_sensor_value'],
            'milk_quality' => $row['quality_status']
        ];
    }
    
    // Return the records as JSON
    echo json_encode(['records' => $records]);
} else {
    echo json_encode(['error' => 'No data found']);
}

// Close connection
$conn->close();
?>
